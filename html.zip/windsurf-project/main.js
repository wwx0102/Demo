// 页面导航函数
function navigate(page) {
    window.webkit.messageHandlers.navigate.postMessage({
        page: page,
        params: {}
    });
}

// 获取用户信息
function getUserInfo() {
    window.webkit.messageHandlers.getUserInfo.postMessage({});
}

// 接收用户信息的回调函数
function receiveUserInfo(userInfo) {
    console.log('Received user info:', userInfo);
    // 在这里可以添加处理用户信息的逻辑
    document.getElementById('userInfo').textContent = JSON.stringify(userInfo, null, 2);
}
